"""
例：12行代码一键截断能测试
需求描述：当前目录已有Vasp输入文件，截断能分别为200、250、300、…、700，每个截断能创建一个文件夹，拷贝输入文件到文件夹内，修改INCAR中的截断能设置，进行前检查并提交任务。
"""

import os, sys
import VaspCZ.zzdlib as zzd

zzd.getshellResult(f'{sys.executable} {zzd.File.VaspCZ_src_path()}/VaspKeepInputs.py')  # 仅保留输入文件。
for encut in range(200, 701, 50):  # 用循环批量处理截断能。
	os.mkdir(str(encut))  # 创建以截断能命名的文件夹。
	os.system(f'cp * {encut}/')  # 将当前目录的下的所有文件拷贝到截断能文件夹。
	os.chdir(str(encut))  # 工作目录进入到截断能文件夹，循环末尾必须带退出返回上一级工作目录。
	data = zzd.File.openFile('INCAR', 'r')  # 以r(read)模式读取INCAR文件，每一行为一个元素写入data列表变量中。
	data_new = zzd.File.substituteData(
		data=data, keywords='ENCUT', newline=f'ENCUT={encut}')  # 修改INCAR中的带有关键词'ENCUT'的行为'ENCUT=当前循环的截断能'
	zzd.File.openFile('INCAR', 'w', data=data_new)  # 以w(write)模式写入INCAR文件，写入的数据为修改后的数据data_new
	os.system(f'cp {zzd.File.Vaspsh_path()}/Vasp.sh .')  # 将适合本计算平台的PBS任务脚本Vasp.sh拷贝到当前文件夹，默认在用户根目录下。
	zzd.Vasp.check_and_qsub()  # 前检查并提交任务。
	os.chdir('..')  # 返回上一级工作目录，与前进入对应，一次循环一进一出。



