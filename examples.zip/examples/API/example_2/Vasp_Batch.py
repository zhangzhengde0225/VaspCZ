import os
import VaspCZ.zzdlib as zzd


def run(elements, nodes, ppn):
	for ele in elements:  # 循环遍历所有元素
		if not os.path.isdir(ele):  # 如果元素文件夹
			os.chdir(ele)  # 创建以元素命名的文件夹
		os.system(f'cp -rf prepare/* {ele}')  # 强制拷贝(包含文件夹)prepare下的所有文件和文件夹到该元素文件夹下。
		for infi in ['ini', 'fin']:  # 循环遍历初态和末态
			os.chdir(f'{ele}/{infi}/Opt')  # 进入元素文件夹下的初态/末态下的Opt文件夹，共3层目录。后面需要退出三层目录
			# INCAR、POTCAR、KPOINTS无需改变
			# POSCAR内元素改为当前元素
			zzd.Vasp.modify_POSCAR_ele(oldele='Cr', new_ele=ele)  # 修改旧元素'Cr'修改为当前元素
			# 产生Vasp.sh
			os.system(f'cp {zzd.File.Vaspsh_path()}/Vasp.sh .')  # 拷贝Vasp.sh到当前目录。
			jobname = f'ex2_{ele}{infi[0]}O'  # 任务名，如：ex2_Cr_iO、ex2_Cr_fO
			zzd.Vasp.modify_Vasp_sh(jobname=jobname, nodes=nodes, ppn=ppn)  # 修改Vasp.sh内的任务名、所需节点数、核数
			zzd.Vasp.check_and_qsub(need_input=False)  # 前检查和提交任务
			os.chdir('../../..')  # 退出三层目录


if __name__ == '__main__':
	elements = 'Al,As,Bi,Co,Cr,Ga,Ge,Ir,Mo,Nb,Ni,P,Pb,Rh,Ru,Sb,Si,Sn,Tc,Ti,V,W,Zn,Cu,Mn,Ag,Au,Cd,Hf,Hg,In,Os,Pd,Pt,Sc,Ta,Tl,Zr,Re'.split(',')
	nodes = 1  # 任务所需节点数
	ppn = 8  # 任务所需核数
	run(elements, nodes, ppn)
