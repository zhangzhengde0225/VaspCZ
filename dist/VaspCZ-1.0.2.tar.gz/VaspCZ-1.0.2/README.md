简介：

VaspCZ(Vasp Check by Zzd)是作者在读博期间为提高科研效率而开发的Vasp辅助程序，该程序包含三个模块：结构优化和静态计算(OS)模块、过渡态计算(NEB)模块和测试(Test)模块，并提供了Linux用户界面。

【程序框架图】

【各个模块功能介绍】

当前版本: 1.0.1

安装和使用

    git clone https://github.com/zhangzhengde0225/VaspCZ.git

    
